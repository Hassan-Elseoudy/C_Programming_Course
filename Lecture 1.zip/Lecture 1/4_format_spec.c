#include <stdio.h>

int main() {

int a = 50;
float b = 100;
printf("%d\n",a);
printf("%3d\n",a);
printf("%s\n","Hassan");
printf("%f\n",b);
printf("%ld\n",a);
printf("%3.2f\n",b);
printf("%c\n",50);
printf("%x\n",50);
printf("%o\n",50);
}

