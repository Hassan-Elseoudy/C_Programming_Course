#include<stdio.h>

int main()
{
  FILE *fp = fopen("test.txt", "r");
  int ch;
  while ((ch = getc(fp)) != EOF)
    printf("%c",ch);
  return 0;
}
