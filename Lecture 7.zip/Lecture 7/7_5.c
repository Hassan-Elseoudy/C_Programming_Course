#include <stdio.h>

int main (void)
{
   FILE *fileName;
   fileName = fopen("anything.txt","w");
   fprintf(fileName, "%s %s %s %d", "Welcome", "to",  "ACM", 2019);
   fclose(fileName);
   return(0);
}