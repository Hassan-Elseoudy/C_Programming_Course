#include <stdio.h>

int main ()
{
  FILE * fileName;
  char ch;
  fileName = fopen("test.txt","a+");
  for (ch = 'A' ; ch <= 'Z' ; ch++) {
    putc (ch , fileName);
    }
  fclose (fileName);
  return 0;
}