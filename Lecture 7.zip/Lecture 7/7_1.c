#include<stdio.h>

int main()
{
    FILE *fp;
    fp = fopen("test.txt","w");
    if(fp != NULL){
        puts("Succeeded");
    }
    else{
        puts("Error!");
    }
    fclose(fp);
    return 0;
}