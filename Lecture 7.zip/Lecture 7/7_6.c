#include<stdio.h>
int main()
{
    FILE* ptr = fopen("ex.txt","r");
    if (ptr==NULL)
    {
        printf("no such file.");
        return 0;
    }
    char first[100];
    char last[100];
    int id;
    while (fscanf(ptr,"%s%d%s",first,&id,last) > 0)
        printf("%s : %d : %s\n", first,id,last);
    return 0;
}
